# Coach Anglais — mise en ligne

## Ce dont tu as besoin
1. Un compte GitHub (gratuit) — github.com
2. Un compte Vercel (gratuit) — vercel.com (connecte-toi avec ton compte GitHub, un clic)
3. Une clé API Anthropic — console.anthropic.com → "Get API Keys" → créer une clé

## Étapes
1. Crée un nouveau repo GitHub (ex: "coach-anglais") et mets-y les 3 fichiers de ce dossier (index.html, package.json, api/lesson.js)
2. Va sur vercel.com → "Add New Project" → importe ton repo GitHub
3. Avant de cliquer "Deploy", ouvre "Environment Variables" et ajoute :
   - Nom: ANTHROPIC_API_KEY
   - Valeur: ta clé (commence par sk-ant-...)
4. Clique "Deploy". En ~1 minute t'as une URL du style coach-anglais.vercel.app
5. Ouvre cette URL sur ton téléphone, ajoute-la à l'écran d'accueil (ça fait comme une vraie app)

## Coût
Chaque leçon générée coûte quelques centimes de crédit API (le modèle Sonnet).
Sur 4 mois à 1 leçon/jour, ça reste très faible (quelques euros au total).
Tu peux surveiller ta consommation sur console.anthropic.com.
